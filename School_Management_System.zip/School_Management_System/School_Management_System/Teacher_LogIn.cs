﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace School_Management_System
{
    public partial class Teacher_LogIn : Form
    {
        SqlCommand ca;
        SqlConnection con;
        DataTable dt;
        SqlDataAdapter adpt;
        string path = "Data Source=DESKTOP-6LJCC8I\\SQLEXPRESS;Initial Catalog=School_Management_System;Integrated Security=True";
        public Teacher_LogIn()
        {
            InitializeComponent();
            con = new SqlConnection(path);
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            con.Open();
            string querry = "select * from Teacher where Email ='"+txtEmail.Text+"' and Password= '"+txtPass.Text+"' ";
            ca = new SqlCommand(querry, con);

            try
            {
                ca.ExecuteNonQuery();
                MessageBox.Show("LogIn Successfully");
                con.Close();
                display();

                //cleardata();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Not Deleted" + ex.Message);
            }
        }
        private void display()
        {
            con.Open();
            string querry = "select*from Teacher where Email ='"+txtEmail.Text+"'";
            dt = new DataTable();
            adpt = new SqlDataAdapter(querry, con);
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 ds = new Form1();
            ds.Show();
            this.Hide();
        }
       
    }
}
