﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace School_Management_System
{
    public partial class Teacher : Form
    {
        SqlCommand ca;
        SqlConnection con;
        DataTable dt;
        SqlDataAdapter adpt;
        string path = "Data Source=DESKTOP-6LJCC8I\\SQLEXPRESS;Initial Catalog=School_Management_System;Integrated Security=True";
        string gender;
        public Teacher()
        {
           
            InitializeComponent();
            con = new SqlConnection(path);
            Display();
            Display1();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtname.Text == "" || txtEmail.Text=="" || txtPass.Text=="" || txtage.Text == "" || txtAddress.Text == "" || txtqua.Text == ""||txtid.Text=="")
                {
                    MessageBox.Show("Please Enter All Values");
                }
                else
                {
                    con.Open();

                    if (rbtnMale.Checked)
                    {
                        gender = "Male";
                    }
                    else
                    {
                        gender = "female";
                    }

                    string qurey = "insert into Teacher values (@id,@name,@gender,@age,@qua,@addresss,@Email,@Pass)";
                    ca = new SqlCommand(qurey, con);
                    ca.Parameters.AddWithValue("@id", txtid.Text);
                    ca.Parameters.AddWithValue("@name", txtname.Text);
                    ca.Parameters.AddWithValue("@gender", gender);
                    ca.Parameters.AddWithValue("@age", int.Parse(txtage.Text));
                    ca.Parameters.AddWithValue("@qua", txtqua.Text);
                    ca.Parameters.AddWithValue("@addresss", txtAddress.Text);
                    ca.Parameters.AddWithValue("@Email", txtEmail.Text);
                    ca.Parameters.AddWithValue("@Pass", txtPass.Text);
                    ca.ExecuteNonQuery();
                    MessageBox.Show("saved");
                    cleardata();
                    con.Close();
                    Display();
                    Display1();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        public void cleardata()
        {

            txtAddress.Clear();
            txtage.Clear();
            txtname.Clear();
            txtqua.Clear();
            txtid.Clear();
        }



        private void btnback_Click(object sender, EventArgs e)
        {
            // Faculty_ g = new Faculty_();
            //   g.Show();
            //  this.Hide();
        }

        private void Teacher_Load(object sender, EventArgs e)
        {

        }
        private void Display1()
        {
            string querry = "select * from Teacher_details";
            con.Open();
            dt = new DataTable();
            adpt = new SqlDataAdapter(querry, con);
            adpt.Fill(dt);
            dataGridView2.DataSource = dt;

            con.Close();
        }
        private void Display()
        {
            string querry = "select * from Teacher";
            con.Open();
            dt = new DataTable();
            adpt = new SqlDataAdapter(querry, con);
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
            
            con.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void btnupdate_Click_1(object sender, EventArgs e)
        {
            
            if (rbtnMale.Checked)
            {
                gender = "Male";
            }
            else 
            {
                gender = "female";
            }
            con.Open();
            ca = new SqlCommand("update teacher set name ='" + txtname.Text + "', gender = '" + this.gender + "',Age ='" + int.Parse(txtage.Text) + "',qualifications ='" + txtqua.Text + "',addresss ='" + txtAddress.Text + "',Email ='" + txtEmail.Text + "',Password ='" + txtPass.Text + "'  where id ='" + txtid.Text + "' ", con);


            try
            {
                ca.ExecuteNonQuery();
                MessageBox.Show("UPdated");

                con.Close();
                cleardata();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Not updated" + ex.Message);
            }
            finally
            {
                con.Close();
            }
            Display();
        }

        private void btndelete_Click_1(object sender, EventArgs e)
        {
            con.Open();
            ca = new SqlCommand("delete from Teacher where ID = " + txtdeID.Text + " ", con);

            try
            {
                ca.ExecuteNonQuery();
                MessageBox.Show("Deleted");
                con.Close();
                cleardata();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Not Deleted" + ex.Message);
            }
            finally
            {
                con.Close();
            }
            Display();
            Display1();
        }

        private void btnback_Click_1(object sender, EventArgs e)
        {
            Faculty d = new Faculty();
            d.Show();
            this.Hide();
        }
    }
}