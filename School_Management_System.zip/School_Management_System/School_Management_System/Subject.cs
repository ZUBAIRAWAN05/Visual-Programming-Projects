﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace School_Management_System
{
    public partial class Subject : Form
    {
        
         SqlCommand ca;
        SqlConnection con;
        DataTable dt;
        SqlDataAdapter adpt;
        string path = "Data Source=DESKTOP-6LJCC8I\\SQLEXPRESS;Initial Catalog=School_Management_System;Integrated Security=True";
     
        public Subject ()
        {
            con = new SqlConnection(path);
            InitializeComponent();
          Display();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtname.Text == "" || txttID.Text == "" ||txtid.Text=="")
                {
                    MessageBox.Show("Please Enter All Values");
                }
                else
                {
                    con.Open();


                    string qurey = "insert into Subjectt  values (@id,@name,@Teacher)";
                    ca = new SqlCommand(qurey, con);
                    ca.Parameters.AddWithValue("@id", txtid.Text);
                    ca.Parameters.AddWithValue("@name", txtname.Text);
                   
                   
                    ca.Parameters.AddWithValue("@Teacher", txttID.Text);
                   
                    ca.ExecuteNonQuery();
                    MessageBox.Show("saved");
                    cleardata();
                    con.Close();
                    Display();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        public void cleardata()
        {

          txttID.Clear();
            txtname.Clear();
           
            txtid.Clear();
        }



        private void btnback_Click(object sender, EventArgs e)
        {
            // Faculty_ g = new Faculty_();
            //   g.Show();
            //  this.Hide();
        }

        private void Teacher_Load(object sender, EventArgs e)
        {

        }
        private void Display()
        {
            string querry = "select subjectt.id as courseID,subjectt.name as subjectName,Teacher.name as teacherName from Subjectt join Teacher on subjectt.Teacher = Teacher.id ";
            con.Open();
            dt = new DataTable();
            ca = new SqlCommand(querry, con);
            adpt = new SqlDataAdapter(ca);
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
            
            con.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void btnupdate_Click_1(object sender, EventArgs e)
        {
          
          
        }

        private void btndelete_Click_1(object sender, EventArgs e)
        {
           
        }

        private void btnback_Click_1(object sender, EventArgs e)
        {
            Faculty d = new Faculty();
            d.Show();
            this.Hide();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            con.Open();
            ca = new SqlCommand("update Subjectt  set name ='" + txtname.Text + "',Teacher ='" + txttID.Text + "'  where id ='" + txtid.Text + "' ", con);


            try
            {
                ca.ExecuteNonQuery();
                MessageBox.Show("UPdated");

                con.Close();
                cleardata();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Not updated" + ex.Message);
            }
            finally
            {
                con.Close();
            }
            Display();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            con.Open();
            ca = new SqlCommand("delete from Subjectt  where id = " + txtdeID.Text + " ", con);

            try
            {
                ca.ExecuteNonQuery();
                MessageBox.Show("Deleted");
                con.Close();
                cleardata();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Not Deleted" + ex.Message);
            }
            finally
            {
                con.Close();
            }
            Display();
        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        

      
    }
       
    }

