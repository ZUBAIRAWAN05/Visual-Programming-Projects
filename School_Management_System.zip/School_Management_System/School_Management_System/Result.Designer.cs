﻿namespace School_Management_System
{
    partial class Result
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtfURDU = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCHIMISTRY = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnback = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtBIOLOGY = new System.Windows.Forms.TextBox();
            this.txtPHYSICS = new System.Windows.Forms.TextBox();
            this.txtISLAMIAT = new System.Windows.Forms.TextBox();
            this.txtMATH = new System.Windows.Forms.TextBox();
            this.txtid = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtempid = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtfURDU
            // 
            this.txtfURDU.Location = new System.Drawing.Point(148, 130);
            this.txtfURDU.Name = "txtfURDU";
            this.txtfURDU.Size = new System.Drawing.Size(100, 22);
            this.txtfURDU.TabIndex = 66;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(44, 130);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 17);
            this.label8.TabIndex = 65;
            this.label8.Text = "URDU:";
            // 
            // txtCHIMISTRY
            // 
            this.txtCHIMISTRY.Location = new System.Drawing.Point(148, 282);
            this.txtCHIMISTRY.Name = "txtCHIMISTRY";
            this.txtCHIMISTRY.Size = new System.Drawing.Size(100, 22);
            this.txtCHIMISTRY.TabIndex = 64;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 282);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 17);
            this.label7.TabIndex = 63;
            this.label7.Text = "CHEMISTRY :";
            // 
            // btnback
            // 
            this.btnback.Location = new System.Drawing.Point(322, 307);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(87, 54);
            this.btnback.TabIndex = 62;
            this.btnback.Text = "BACK";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(322, 233);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(87, 54);
            this.btnExit.TabIndex = 61;
            this.btnExit.Text = "EXIT";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(322, 114);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(87, 54);
            this.btnupdate.TabIndex = 60;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(322, 174);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(87, 54);
            this.btndelete.TabIndex = 59;
            this.btndelete.Text = "DELETE";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(322, 50);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(87, 54);
            this.btnSave.TabIndex = 58;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(525, 33);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(403, 447);
            this.dataGridView1.TabIndex = 57;
            // 
            // txtBIOLOGY
            // 
            this.txtBIOLOGY.Location = new System.Drawing.Point(148, 233);
            this.txtBIOLOGY.Name = "txtBIOLOGY";
            this.txtBIOLOGY.Size = new System.Drawing.Size(100, 22);
            this.txtBIOLOGY.TabIndex = 56;
            // 
            // txtPHYSICS
            // 
            this.txtPHYSICS.Location = new System.Drawing.Point(148, 200);
            this.txtPHYSICS.Name = "txtPHYSICS";
            this.txtPHYSICS.Size = new System.Drawing.Size(100, 22);
            this.txtPHYSICS.TabIndex = 55;
            // 
            // txtISLAMIAT
            // 
            this.txtISLAMIAT.Location = new System.Drawing.Point(148, 162);
            this.txtISLAMIAT.Name = "txtISLAMIAT";
            this.txtISLAMIAT.Size = new System.Drawing.Size(100, 22);
            this.txtISLAMIAT.TabIndex = 54;
            // 
            // txtMATH
            // 
            this.txtMATH.Location = new System.Drawing.Point(148, 87);
            this.txtMATH.Name = "txtMATH";
            this.txtMATH.Size = new System.Drawing.Size(100, 22);
            this.txtMATH.TabIndex = 53;
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(148, 45);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(100, 22);
            this.txtid.TabIndex = 52;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 236);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 17);
            this.label5.TabIndex = 48;
            this.label5.Text = "BIOLOGY :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(38, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 17);
            this.label4.TabIndex = 47;
            this.label4.Text = "ISLAMIAT :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 17);
            this.label3.TabIndex = 46;
            this.label3.Text = "PHYSICS ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 17);
            this.label2.TabIndex = 45;
            this.label2.Text = "MATH";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 44;
            this.label1.Text = "student ID :";
            // 
            // txtempid
            // 
            this.txtempid.Location = new System.Drawing.Point(148, 323);
            this.txtempid.Name = "txtempid";
            this.txtempid.Size = new System.Drawing.Size(100, 22);
            this.txtempid.TabIndex = 68;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(-10, 323);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 17);
            this.label6.TabIndex = 67;
            this.label6.Text = "Exam_employee ID :";
            // 
            // Result
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(929, 512);
            this.Controls.Add(this.txtempid);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtfURDU);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtCHIMISTRY);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtBIOLOGY);
            this.Controls.Add(this.txtPHYSICS);
            this.Controls.Add(this.txtISLAMIAT);
            this.Controls.Add(this.txtMATH);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Result";
            this.Text = "Result";
            this.Load += new System.EventHandler(this.Result_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtfURDU;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCHIMISTRY;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtBIOLOGY;
        private System.Windows.Forms.TextBox txtPHYSICS;
        private System.Windows.Forms.TextBox txtISLAMIAT;
        private System.Windows.Forms.TextBox txtMATH;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtempid;
        private System.Windows.Forms.Label label6;
    }
}