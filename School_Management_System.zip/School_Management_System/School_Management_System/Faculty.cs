﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_Management_System
{
    public partial class Faculty : Form
    {
        public Faculty()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Teacher_ t = new Teacher_();
            t.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Fee_Empolyee d = new Fee_Empolyee();
            d.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Exam_Empolyee ed = new Exam_Empolyee();
            ed.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Security_guard ds = new Security_guard();
            ds.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Workers ew = new Workers();
            ew.Show();
            this.Hide();
        }

        private void btnSubject_Click(object sender, EventArgs e)
        {
            Subject sd = new Subject();
            sd.Show();
            this.Hide();
        }

        private void btnClass_Click(object sender, EventArgs e)
        {
            @class s = new @class();
            s.Show();
            this.Hide();
        }

        private void btnresult_Click(object sender, EventArgs e)
        {
            Result sd = new Result();
            sd.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 df = new Form1();
            df.Show();
            this.Hide();
        }
    }
}
