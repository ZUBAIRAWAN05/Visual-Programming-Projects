﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFaculty_Click(object sender, EventArgs e)
        {
            splash t = new splash();
            t.Show();
            this.Hide();
        }

        private void btnSP_Click(object sender, EventArgs e)
        {
            Students sd = new Students();
            sd.Show();
            this.Hide();
        }

        private void btnexam_Click(object sender, EventArgs e)
        {
            Result sd = new Result();
            sd.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
