﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace School_Management_System
{
    public partial class Result : Form
    {
        SqlCommand ca;
        SqlConnection con;
        DataTable dt;
        SqlDataAdapter adpt;
        string path = "Data Source=DESKTOP-6LJCC8I\\SQLEXPRESS;Initial Catalog=School_Management_System;Integrated Security=True";
        string gender;
        public Result()
        {
            con = new SqlConnection(path);
            InitializeComponent();
            Display();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBIOLOGY.Text == "" || txtCHIMISTRY.Text == "" || txtfURDU.Text == "" || txtid.Text == "" || txtISLAMIAT.Text == "" || txtMATH.Text=="" || txtPHYSICS.Text=="")
                {
                    MessageBox.Show("Please Enter All Values");
                }
                else
                {
                    con.Open();

                   
                    string qurey = "insert into Result values (@Student,@math,@urdu,@islamiat,@physics,@biology,@chemistry,@id)";
                    ca = new SqlCommand(qurey, con);
                    ca.Parameters.AddWithValue("@Student", txtid.Text);
                    ca.Parameters.AddWithValue("@math", txtMATH.Text);
                    ca.Parameters.AddWithValue("@urdu", txtfURDU.Text);
                    ca.Parameters.AddWithValue("@islamiat", txtISLAMIAT.Text);
                    ca.Parameters.AddWithValue("@physics", txtPHYSICS.Text);
                    ca.Parameters.AddWithValue("@biology", txtBIOLOGY.Text);
                    ca.Parameters.AddWithValue("@chemistry", txtCHIMISTRY.Text);
                    ca.Parameters.AddWithValue("@id", txtempid.Text);
                    ca.ExecuteNonQuery();
                    MessageBox.Show("saved");
                    cleardata();
                    con.Close();
                    Display();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        public void cleardata()
        {
            txtCHIMISTRY.Clear();
            txtBIOLOGY.Clear();
            txtfURDU.Clear();
            txtISLAMIAT.Clear();
            txtMATH.Clear();
            txtPHYSICS.Clear();
            txtid.Clear();
            txtempid.Clear();
        }
        private void Display()
        {
            string querry = "select Student.name as Student_name,Student.Father_name,Math,urdu,islamiat,physics,biology,chemistry,Exam_Employee.name as managed_by from Result join Student on Result.Student =Student.id join Exam_Employee on Result.id = Exam_Employee.id" ;
            con.Open();
            dt = new DataTable();
            ca = new SqlCommand(querry, con);
            adpt = new SqlDataAdapter(ca);
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        

        private void btnupdate_Click(object sender, EventArgs e)
        {
      
            con.Open();
            ca = new SqlCommand("update Result set math ='" + txtMATH.Text + "', urdu = '" + txtfURDU.Text + "',islamiat ='" + txtISLAMIAT.Text + "',physics='" + txtPHYSICS.Text+ "',biology ='" + txtBIOLOGY.Text + "',chemistry='"+txtCHIMISTRY.Text+"' ,id='"+txtempid.Text+"',id ='"+txtempid.Text+"' where Student ='" + txtid.Text + "' ", con);


            try
            {
                ca.ExecuteNonQuery();
                MessageBox.Show("UPdated");

                con.Close();
                cleardata();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Not updated" + ex.Message);
            }
            finally
            {
                con.Close();
            }
            Display();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Form1 ed = new Form1();
            ed.Show();
            this.Hide();
        }

        private void Result_Load(object sender, EventArgs e)
        {

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            con.Open();
            ca = new SqlCommand("delete from Teacher where Student = " +txtid.Text  + " ", con);

            try
            {
                ca.ExecuteNonQuery();
                MessageBox.Show("Deleted");
                con.Close();
                cleardata();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Not Deleted" + ex.Message);
            }
            finally
            {
                con.Close();
            }
            Display();
        }

        private void btnback_Click_1(object sender, EventArgs e)
        {
            Faculty d = new Faculty();
            d.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
             System.Environment.Exit(0);
        }

        }

      
    }

