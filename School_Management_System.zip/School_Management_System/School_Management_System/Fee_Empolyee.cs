﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;
namespace School_Management_System
{
    public partial class Fee_Empolyee : Form
    {
         SqlCommand ca;
        SqlConnection con;
        DataTable dt;
        SqlDataAdapter adpt;
        string path = "Data Source=DESKTOP-6LJCC8I\\SQLEXPRESS;Initial Catalog=School_Management_System;Integrated Security=True";
        string gender = null;
        public Fee_Empolyee()
        {
            con = new SqlConnection(path);
            InitializeComponent();
           Display();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
           


        }

        public void cleardata()
        {

            txtAddress.Clear();
            txtage.Clear();
            txtname.Clear();
            txtqua.Clear();
            txtid.Clear();
        }



        private void btnback_Click(object sender, EventArgs e)
        {
            // Faculty_ g = new Faculty_();
            //   g.Show();
            //  this.Hide();
        }

        private void Teacher_Load(object sender, EventArgs e)
        {

        }
        private void Display()
        {
            string querry = "select * from Fee_Employee";
            con.Open();
            dt = new DataTable();
            adpt = new SqlDataAdapter(querry, con);
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
            
            con.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void btnupdate_Click_1(object sender, EventArgs e)
        {
            
        }

        private void btndelete_Click_1(object sender, EventArgs e)
        {
           
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (txtname.Text == "" || txtage.Text == "" || txtAddress.Text == "" || txtqua.Text == "" || txtid.Text == "")
                {
                    MessageBox.Show("Please Enter All Values");
                }
                else
                {
                    con.Open();

                    if (rbtnMale.Checked)
                    {
                        gender = "Male";
                    }
                    else if (rbtnFemale.Checked)
                    {
                        gender = "female";
                    }

                    string qurey = "insert into Fee_Employee values (@id,@name,@gender,@age,@qua,@addresss)";
                    ca = new SqlCommand(qurey, con);
                    ca.Parameters.AddWithValue("@id", txtid.Text);
                    ca.Parameters.AddWithValue("@name", txtname.Text);
                    ca.Parameters.AddWithValue("@gender", gender);
                    ca.Parameters.AddWithValue("@age", int.Parse(txtage.Text));
                    ca.Parameters.AddWithValue("@qua", txtqua.Text);
                    ca.Parameters.AddWithValue("@addresss", txtAddress.Text);
                    ca.ExecuteNonQuery();
                    MessageBox.Show("saved");
                    cleardata();
                    con.Close();
                    Display();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnback_Click_1(object sender, EventArgs e)
        {
            Faculty d = new Faculty();
            d.Show();
            this.Hide();
        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

            if (rbtnMale.Checked)
            {
                gender = "Male";
            }
            else
            {
                gender = "female";
            }
            con.Open();
            ca = new SqlCommand("update Fee_Employee set name ='" + txtname.Text + "', gender = '" + this.gender + "',Age ='" + txtage.Text + "',qualifications ='" + txtqua.Text + "',addresss ='" + txtAddress.Text + "'  where id ='" + txtid.Text + "' ", con);


            try
            {
                ca.ExecuteNonQuery();
                MessageBox.Show("UPdated");

                con.Close();
                cleardata();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Not updated" + ex.Message);
            }
            finally
            {
                con.Close();
            }
            Display();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            con.Open();
            ca = new SqlCommand("delete from Fee_Employee where ID = " + txtdeID.Text + " ", con);

            try
            {
                ca.ExecuteNonQuery();
                MessageBox.Show("Deleted");
                con.Close();
                cleardata();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Not Deleted" + ex.Message);
            }
            finally
            {
                con.Close();
            }
            Display();
        }
    }
}
