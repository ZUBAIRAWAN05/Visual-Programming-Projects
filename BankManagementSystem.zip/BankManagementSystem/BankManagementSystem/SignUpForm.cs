﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BankManagementSystem
{
    public partial class SignUpForm : Form
    {
        String str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Study Material\C#Projects\BankManagementSystem\BankManagementSystem\MyBank_DB.mdf;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        public SignUpForm()
        {
            InitializeComponent();
            con=new SqlConnection(str);
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text=="" || txtPass.Text=="")
            {
                MessageBox.Show("Please fill the spaces");
            }
            else
            {
                try
                {
                    con.Open();
                    String querry = "insert into tb_SignUp values('"+txtEmail.Text+"','"+txtPass.Text+"')";
                    cmd=new SqlCommand(querry,con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Your account has been saved in Bank");
                    LogInForm logInForm = new LogInForm();
                    logInForm.Show();
                    this.Hide();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnSignIn_Click(object sender, EventArgs e)

        {
            MessageBox.Show("If u have already Account move to next Page \n or signup your account", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
           
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("MycodeSpace@gmail.com", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnContact_Click(object sender, EventArgs e)
        {
            MessageBox.Show("03365146534", "Contact", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LogInForm l = new LogInForm();
            l.Show();
            this.Hide();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0); 
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WelcomeForm welcomeForm = new WelcomeForm();
            welcomeForm.Show();
            this.Hide();
        }
    }
}
