﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankManagementSystem
{
    public partial class ManagerForm : Form
    {
        String str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Study Material\C#Projects\BankManagementSystem\BankManagementSystem\MyBank_DB.mdf;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter adpt;
        public ManagerForm()
        {
            InitializeComponent();
            con = new SqlConnection(str);
            display();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtMName.Text == "" || txtBranchName.Text == "" || txtBranchCode.Text == "" || txtBrAddress.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    
                    con.Open();
                    String querry = "insert into tb_Manager values('" + txtMName.Text + "','" + txtBranchName.Text + "','" + txtBranchCode.Text + "','" + txtBrAddress.Text + "')";
                    cmd = new SqlCommand(querry, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("New Manager has been stored");
                    clear();
                    display();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtMName.Text == "" || txtBranchName.Text == "" || txtBranchCode.Text == "" || txtBrAddress.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {

                    con.Open();
                    String querry = "update  tb_Manager set M_Name='" + txtMName.Text + "',Branch='" + txtBranchName.Text + "',Branch_Code='" + txtBranchCode.Text + "',Branch_Address='" + txtBrAddress.Text + "' where M_Name='"+txtMName.Text+"')";
                    cmd = new SqlCommand(querry, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show(" Manager has been Updated");
                    clear();
                    display();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();
            String querry = "delete from tb_Manager where M_Name='" + txtMName.Text + "'";
            cmd = new SqlCommand(querry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Manager Record  has been deleted!");
            clear();
            display();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SignUpForm signUpForm = new SignUpForm();
            signUpForm.Show();
            this.Hide();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0); 
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TransactionHistoryForm transactionHistoryForm = new TransactionHistoryForm();
            transactionHistoryForm.Show();
            this.Hide();
        }

        private void prevToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TransactionForm transactionForm = new TransactionForm();    
            transactionForm.Show();
            this.Hide();
        }
        private void display()
        {

            dt = new DataTable();
            con.Open();
            String querry = "Select * from tb_Manager";
            adpt = new SqlDataAdapter(querry, con);
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        private void clear()
        {
            txtMName.Text = "";
            txtBranchName.Text = "";
            txtBranchCode.Text = "";
            txtBrAddress.Text = "";

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            display();
        }
    }
}
