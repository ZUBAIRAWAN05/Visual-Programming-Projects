﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankManagementSystem
{
    public partial class ManageAgentForm : Form
    {
        String str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Study Material\C#Projects\BankManagementSystem\BankManagementSystem\MyBank_DB.mdf;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter adpt;
        public ManageAgentForm()
        {
            InitializeComponent();
            con = new SqlConnection(str);
            display();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SignUpForm c = new SignUpForm();
            c.Show();
            this.Hide();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void prevToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UserAccInfoForm c = new UserAccInfoForm();
            c.Show();
            this.Hide();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtPass.Text == "" || txtAddress.Text == "" || txtContact.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {

                    con.Open();
                    String querry = "insert into tb_ManageAgent values('" + txtName.Text + "','" + txtPass.Text + "','" + txtAddress.Text + "','" + txtContact.Text + "')";
                    cmd = new SqlCommand(querry, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("User Acc_Information has been stored");
                    clear();
                    display();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            con.Open();
            String querry = "update tb_ManageAgent set Name='" + txtName.Text + "',Pass='" + txtAddress.Text + "',Contact='" + txtContact.Text + "' where Name='" + txtName.Text + "' ";
            cmd = new SqlCommand(querry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data has been update");
            clear();
            display();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            con.Open();
            String querry = "delete from tb_ManageAgent where Name='" + txtName.Text + "'";
            cmd = new SqlCommand(querry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record has been deleted!");
            clear();
            display();
        }
        private void clear()
        {
            txtAddress.Text = "";
            txtContact.Text = "";
            txtName.Text = "";
            txtPass.Text = "";
        }
        private void display()
        {
            dt = new DataTable();
            con.Open();
            String querry = "Select * from tb_ManageAgent";
            adpt = new SqlDataAdapter(querry, con);
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TransactionForm transactionForm = new TransactionForm();
            transactionForm.Show();
            this.Hide();
        }
    }
}