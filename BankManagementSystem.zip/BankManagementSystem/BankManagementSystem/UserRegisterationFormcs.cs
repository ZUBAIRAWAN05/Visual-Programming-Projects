﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankManagementSystem
{
    public partial class UserRegisterationFormcs : Form
    {

        String str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Study Material\C#Projects\BankManagementSystem\BankManagementSystem\MyBank_DB.mdf;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter adpt;
        public UserRegisterationFormcs()
        {
            InitializeComponent();
            con=new SqlConnection(str);
            display();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            if(txtName.Text =="" || txtFname.Text =="" || txtDob.Text=="" || txtCnic.Text== "" || txtAddress.Text=="" || cbCity.Text=="" || cbCountry.Text=="" || cbProvince.Text=="")
            {
                MessageBox.Show("Fill the Blank Spaces");
            }
            else
            {
                try
                {
                    String gender;
                    if (rbtnMale.Checked)
                    {
                        gender = "Male";
                    }
                    else
                    {
                        gender = "Female";
                    }                    con.Open();
                    String querry = "insert into tb_userInfo values('"+txtName.Text+ "','" + txtFname.Text + "','" + txtDob.Text + "','" + txtCnic.Text + "','" + gender+ "','" + cbCountry.Text + "','" + cbProvince.Text + "','" + cbCity.Text + "','" + txtAddress.Text + "')";
                    cmd = new SqlCommand(querry, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("User Information has been stored");
                    clear();
                    display();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                String Gender;
                if (rbtnMale.Checked)
                {
                    Gender = "Male";
                }
                else
                {
                    Gender = "Female";
                }
                con.Open();
                String querry = "update tb_userInfo set Name='" + txtName.Text + "', FName='" + txtFname.Text + "', Dob='" + txtDob.Text + "',Cnic='"+txtCnic.Text+"',Gender='"+Gender+"',Country='"+cbCountry.Text+"',Province='"+cbProvince.Text+ "',City='"+cbCity.Text+ "',Address='"+txtAddress.Text+"' where Name='" + txtName.Text + "' ";
                cmd = new SqlCommand(querry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Your Data has been Updated in the Database ");
                clear();
                display();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            
            con.Open();
            String querry = "delete from tb_userInfo where Name='" + txtName.Text + "'";
            cmd = new SqlCommand(querry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record has been deleted!");
            clear();
            display();
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            display();
        }
        private void clear()
        {
            txtName.Text = "";
            txtFname.Text = "";
            txtCnic.Text = "";
            txtAddress.Text = "";
            cbCity.Text = "";
            cbProvince.Text = "";
            cbCountry.Text = "";
            txtDob.Text = "";
            
        }
        private void display()
        {
            try
            {
                dt = new DataTable();
                con.Open();
                String querry = "Select * from tb_userInfo";
                adpt = new SqlDataAdapter(querry, con);
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void UserRegisterationFormcs_Load(object sender, EventArgs e)
        {
            string[] arr = {"Pakistan","India","USA","UAE" };
            foreach(String s in arr)
            {
                cbCountry.Items.Add(s);
            }
        }

        private void cbProvince_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbCity.Items.Clear();
            if (cbProvince.SelectedItem.ToString() == "Punjab")
            {
                cbCity.Items.Add("Attock");
                cbCity.Items.Add("Kamra Kalan");
                cbCity.Items.Add("Hazro");
                cbCity.Items.Add("Rawalpindi");
            }
            if (cbProvince.SelectedItem.ToString() == "KPK")
            {
                cbCity.Items.Add("Peshawar");
                cbCity.Items.Add("Nowshera");
                cbCity.Items.Add("Sawat");
                cbCity.Items.Add("Sawabi");
            }
            if (cbProvince.SelectedItem.ToString() == "Balochistan")
            {
                cbCity.Items.Add("Thar");
                cbCity.Items.Add("Deer");
                cbCity.Items.Add("Gilgit");
                cbCity.Items.Add("Balochi");
            }
            if (cbProvince.SelectedItem.ToString() == "Sindh")
            {
                cbCity.Items.Add("Karachi");
                cbCity.Items.Add("Multan");
                cbCity.Items.Add("Hyderabad");
                cbCity.Items.Add("Bahawalpur");
            }
        }

        private void cbCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbProvince.Items.Clear();
            if (cbCountry.SelectedItem.ToString() == "Pakistan")
            {
                cbProvince.Items.Add("Punjab");
                cbProvince.Items.Add("KPK");
                cbProvince.Items.Add("Balochistan");
                cbProvince.Items.Add("Sindh");
            }
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SignUpForm signUpForm = new SignUpForm();   
            signUpForm.Show();
            this.Hide();
        }

        private void prevToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LogInForm c = new LogInForm();
            c.Show();
            this.Hide();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UserAccInfoForm c = new UserAccInfoForm();
            c.Show();
            this.Hide();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
