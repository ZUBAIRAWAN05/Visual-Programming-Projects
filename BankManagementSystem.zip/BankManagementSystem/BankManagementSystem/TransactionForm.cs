﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankManagementSystem
{
    public partial class TransactionForm : Form
    {

        String str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Study Material\C#Projects\BankManagementSystem\BankManagementSystem\MyBank_DB.mdf;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter adpt;
        int balance;
        public TransactionForm()
        {
            InitializeComponent();
            con = new SqlConnection(str);
            
        }

        private void btnCheckBal_Click(object sender, EventArgs e)
        {
            if (txtChkBal.Text == "")
            {
                MessageBox.Show("Enter Account Number");
            }
            else
            {
                checkBalance();
                if (lbBal.Text == "Your Balance")
                {
                    MessageBox.Show("Account Not Found");
                    lbBal.Text = "";

                }

            }
        } 

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            if(txtAmountDep.Text=="" || txtAccNoDep.Text != txtChkBal.Text)
            {
                MessageBox.Show("Please check your acount number ");
            }
            else
            {
                deposit();
                getnewBal(txtAccNoDep.Text);
                
                try
                {
                    int newBal = balance + Convert.ToInt32(txtAmountDep.Text);
                    con.Open();
                    String querry = "update tb_AccInfo set Account_Balance='"  +newBal+  "' where Account_No='" + txtAccNoDep.Text + "' ";
                    cmd = new SqlCommand(querry, con);
                    cmd.ExecuteNonQuery();
                    
                    con.Close();
                    txtAccNoDep.Text ="";
                    txtAmountDep.Text = "";
                   
                    
                   
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    
                }
            }
        }
       

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SignUpForm signUpForm = new SignUpForm();
            signUpForm.Show();
            this.Hide();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void prevToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageAgentForm manageAgentForm = new ManageAgentForm();    
            manageAgentForm.Show();
            this.Hide();
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManagerForm managerForm = new ManagerForm();
            managerForm.Show();
            this.Hide();
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {

            if (txtAMountWDraw.Text == "" || txtAccNoWDraw.Text != txtChkBal.Text)
            {
                MessageBox.Show("Please check your acount number ");
            }
            else
            {
                
                withdraw();
                getnewBal(txtAccNoWDraw.Text);
                if (balance< Convert.ToInt32(txtAMountWDraw.Text))
                {
                    MessageBox.Show("Insufficient Balance");
                }
                else{
                      
                    try
                    {
                        int newBal = balance - Convert.ToInt32(txtAMountWDraw.Text);

                        con.Open();
                        String querry = "update tb_AccInfo set Account_Balance='" + newBal + "' where Account_No='" + txtAccNoWDraw.Text + "' ";
                        cmd = new SqlCommand(querry, con);
                        cmd.ExecuteNonQuery();
                        
                        con.Close();
                        txtAccNoWDraw.Text = "";
                        txtAMountWDraw.Text = "";
                        


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        con.Close();
                    }
                }

               
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            lbBal.Text = "Your Balance";
        }
       

        private void deleteTransactionToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }
        private void deposit()
        {

            try
            {
                con.Open();
                String querry = "insert into tb1_Transaction values('" + "deposit" + "','" + DateTime.Now.Date + "','" + txtAmountDep.Text + "','" + txtChkBal.Text + "','" + balance + "')";

                cmd = new SqlCommand(querry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Money Deposit!");
                


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }
        }

        private void withdraw()
        {

            try
            {
                con.Open();
                String querry = "insert into tb1_Transaction values('" + "WithDrawan" + "','" + DateTime.Now.Date + "','" + txtAMountWDraw.Text + "','" + txtAccNoWDraw.Text + "','"+balance+"')";

                cmd = new SqlCommand(querry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Money withdrawn!");
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if(txtTFrom.Text=="")
            {
                MessageBox.Show("Enter source Account Number");
            }
            else
            {
                con.Open();
                adpt = new SqlDataAdapter("select count(*) from tb_AccInfo where Account_No='" + txtTFrom.Text + "'",con);
                dt=new DataTable();
                adpt.Fill(dt);
                if (dt.Rows[0][0].ToString() == "1")
                {
                    chkAvaBal();
                    //labBal.Text = "Rs";
                    con.Close();

                }
                else
                {
                    MessageBox.Show("Account Does Not exist");
                    txtTFrom.Text = "";
                }
                con.Close();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (txtTraTo.Text == "")
            {
                MessageBox.Show("Enter Destination Account Number");
            }
            else
            {
                con.Open();
                adpt = new SqlDataAdapter("select count(*) from tb_AccInfo where Account_No='" + txtTraTo.Text + "'", con);
                dt = new DataTable();
                adpt.Fill(dt);
                if (dt.Rows[0][0].ToString() == "1")
                {
                    // chkAvaBal();
                    MessageBox.Show("Account Found!!");
                    //labBal.Text = "Rs";
                    con.Close();
                    if(txtTraTo.Text == txtTFrom.Text)
                    {
                        MessageBox.Show("Source and destination accounts are same");
                        txtTraTo.Text = "";
                    }

                }
                else
                {
                    MessageBox.Show("Account Does Not exist");
                    txtTraTo.Text = "";
                }
                con.Close();
            }
        }
        private void transfer()
        {
            try
            {
                con.Open();
                String querry = "insert into tb_Transfer values('" + txtTFrom.Text + "','" + txtTraTo.Text + "','" + txtTraAmount.Text + "','" + DateTime.Now.Date+"')";

                cmd = new SqlCommand(querry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Money Transfered!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        

        private void chkAvaBal()
        {

            if (txtTFrom.Text == "")
            {
                MessageBox.Show("Enter Account Number");
            }
            else
            {
                try
                {

                   // con.Open();
                    String querry = "select * from tb_AccInfo where Account_No='" + txtTFrom.Text + "'";
                    cmd = new SqlCommand(querry, con);
                    dt = new DataTable();
                    adpt = new SqlDataAdapter(cmd);
                    adpt.Fill(dt);
                    foreach (DataRow dr in dt.Rows)
                    {
                        labBal.Text = "Rs" + dr["Account_Balance"];
                        balance = Convert.ToInt32(dr["Account_Balance"]);
                    }
                    
                    if (lbBal.Text == "Your Balance")
                    {
                        MessageBox.Show("Account Not Found");
                        
                    }

                    //con.Close();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                   // con.Close();
                }

            }
        }
        private void subtractbal()
        {
            getnewBal(txtTFrom.Text);
                int  newBal =balance-Convert.ToInt32(txtTraAmount.Text);
                try
                {
                    
                    con.Open();
                    String querry = "update tb_AccInfo set Account_Balance='" + newBal + "' where Account_No='" + txtTFrom.Text + "' ";
                    cmd = new SqlCommand(querry, con);
                    cmd.ExecuteNonQuery();
                    
                    con.Close(); 
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    con.Close();
                }
        }
        private void Addbal()
        {
            
            getnewBal(txtTraTo.Text);
             int newBal = balance + Convert.ToInt32(txtTraAmount.Text);
            try
            {

                con.Open();
                String querry = "update tb_AccInfo set Account_Balance='" + newBal + "' where Account_No='" + txtTraTo.Text + "' ";
                cmd = new SqlCommand(querry, con);
                cmd.ExecuteNonQuery();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
        }
        private void getnewBal(String account)
        {

            con.Open();
            String querry = "select * from tb_AccInfo where Account_No='" + txtChkBal.Text + "'";
            cmd = new SqlCommand(querry, con);
            dt = new DataTable();
            adpt = new SqlDataAdapter(cmd);
            adpt.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                //lbBal.Text = "Rs" + dr["Account_Balance"].ToString();
                 balance = Convert.ToInt32(dr["Account_Balance"]);
            }
            con.Close();
        }
        private void btnTransfer_Click(object sender, EventArgs e)
        {
            if (txtTraAmount.Text == "" || txtTFrom.Text == "" || txtTraTo.Text == "")
            {
                MessageBox.Show("Missing Information");
            }

            else
            {
                transfer();
                subtractbal();
                Addbal();
                txtTFrom.Text = "";
                txtTraTo.Text = "";
                txtTraAmount.Text = "";
            }
        }
        private void checkBalance()
        {
            con.Open();
            String querry = "select * from tb_AccInfo where Account_No='" + txtChkBal.Text + "'";
            cmd = new SqlCommand(querry, con);
            dt = new DataTable();
            adpt = new SqlDataAdapter(cmd);
            adpt.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                lbBal.Text = "Rs" + dr["Account_Balance"].ToString();
                balance = Convert.ToInt32(dr["Account_Balance"]);
                
                
            }

            con.Close();
        }
    }
    }

