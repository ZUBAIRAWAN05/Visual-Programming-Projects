﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankManagementSystem
{
    public partial class UserAccInfoForm : Form
    {
        String str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Study Material\C#Projects\BankManagementSystem\BankManagementSystem\MyBank_DB.mdf;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter adpt;
        public UserAccInfoForm()
        {
            InitializeComponent();
            con=new SqlConnection(str);
            display();
            display2();
        }

        private void UserAccInfoForm_Load(object sender, EventArgs e)
        {
            string[] arr = { "Usd Dollar","PKR","Yuan","Dirham","Riyal","Euro","Pound" };
            foreach(string s in arr)
            {
                cbCurrency.Items.Add(s);
            }
            String[] arr2 = { "Current", "Saving", "Fixed", "Deposit" };
            foreach(string i in arr2)
            {
                cbAccType.Items.Add(i);
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (txtAccBalance.Text == "" || txtBankName.Text == "" || txtBranch.Text == "" || txtAccno.Text == "" || txtNameonAcc.Text == "" || cbAccType.Text == "" || cbAccType.Text == "" || txtAccount.Text == "" || txtConfAcc.Text == "" || cbCurrency.Text == "" || txtDescription.Text == "") 
            {
                MessageBox.Show("Missing Information");
            } 
            else
            {
                try
                {
                    String primary;
                    if (rbtnYes.Checked)
                    {
                        primary = "Yes";
                    }
                    else
                    {
                        primary = "No";
                    }
                    con.Open();
                    String querry = "insert into tb_AccInfo values('" + txtBankName.Text + "','" + txtBranch.Text + "','" + txtAccno.Text + "','" + txtNameonAcc.Text + "','" + cbAccType.Text + "','" + primary + "','" + txtAccount.Text + "','" + txtConfAcc.Text + "','" + cbCurrency.Text + "','"+txtDescription.Text+"' , '"+txtAccBalance.Text+"')";
                    cmd = new SqlCommand(querry, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("User Acc_Information has been stored");
                    clear();
                    display2();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtAccBalance.Text == "" || txtBankName.Text == "" || txtBranch.Text == "" || txtAccno.Text == "" || txtNameonAcc.Text == "" || cbAccType.Text == "" || cbAccType.Text == "" || txtAccount.Text == "" || txtConfAcc.Text == "" || cbCurrency.Text == "" || txtDescription.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    String primary;
                    if (rbtnYes.Checked)
                    {
                        primary = "Yes";
                    }
                    else
                    {
                        primary = "No";
                    }
                    con.Open();
                    String querry = "update tb_AccInfo set Branch_Name='" + txtBranch.Text + "',Account_No='" + txtAccno.Text + "',Name_On_Acc='" + txtNameonAcc.Text + "',Acc_Type='" + cbAccType.Text + "',Primary='" + primary + "',Account#='" + txtAccount.Text + "',Account_Confirm='" + txtConfAcc.Text + "',Currency='" + cbCurrency.Text + "',Discription='" + txtDescription.Text + "', Account_Balance='"+txtAccBalance.Text+"' where Bank_Name='"+txtBankName.Text+"' ";
                    cmd = new SqlCommand(querry, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("User Acc_Info has been stored");
                    clear();
                    display2();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();
            String querry = "delete from tb_AccInfo where Bank_Name='" + txtBankName.Text + "'";
            cmd = new SqlCommand(querry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record has been deleted!");
            clear();
            display2();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            display();
        }
        private void display()
        {
            try
            {
                dt = new DataTable();
                con.Open();
                String querry = "Select * from tb_userInfo";
                
                adpt = new SqlDataAdapter(querry, con);
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        private void clear()
        {
            txtBankName.Text = "";
            txtBranch.Text = "";
            txtAccno.Text = "";
            txtNameonAcc.Text = "";
            cbAccType.Text = "";

            txtAccount.Text = "";
            txtConfAcc.Text = "";
            cbCurrency.Text = "";
            txtDescription.Text = "";
            txtAccBalance.Text = "";
           
        }

        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void prevToolStripMenuItem_Click(object sender, EventArgs e)
        {
          UserRegisterationFormcs c=new UserRegisterationFormcs();
            c.Show();
            this.Hide();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SignUpForm signUpForm = new SignUpForm();
            signUpForm.Show();
            this.Hide();
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TransactionForm transactionForm = new TransactionForm();
            transactionForm.Show();
            this.Hide();
        }
        private void display2()
        {

            dt = new DataTable();
            con.Open();
            String querry = "Select * from tb_AccInfo";
            adpt = new SqlDataAdapter(querry, con);
            adpt.Fill(dt);
            dataGridView2.DataSource = dt;
            con.Close();
        }
    }
}
