﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankManagementSystem
{
    public partial class TransactionHistoryForm : Form
    {
        String str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Study Material\C#Projects\BankManagementSystem\BankManagementSystem\MyBank_DB.mdf;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter adpt;
        public TransactionHistoryForm()
        {
         
            InitializeComponent();
            con = new SqlConnection(str);
            //display();
        }

        private void TransactionHistoryForm_Load(object sender, EventArgs e)
        {

        }
        private void display()
        {
            try
            {
                dt = new DataTable();
                con.Open();
                String querry = "Select * from tb1_Transaction";
                adpt = new SqlDataAdapter(querry, con);
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtACCNO.Text == "")
            {
                MessageBox.Show("Enter Account Number");
            }
            else
            {
                try
                {


                    adpt = new SqlDataAdapter("Select * from tb1_Transaction where TAccNum like '%" + txtACCNO.Text + "%' ", con);
                    dt = new DataTable();
                    adpt.Fill(dt);
                    dataGridView1.DataSource = dt;
                    con.Close();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    con.Close();
                }

            }
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LogInForm logInForm = new LogInForm();
            logInForm.Show();
            this.Show();
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LogOutForm logOutForm = new LogOutForm();
            logOutForm.Show();
            this.Hide();
        }

        private void prevToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TransactionForm transactionForm = new TransactionForm();
            transactionForm.Show();
            this.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
