﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BankManagementSystem
{
    public partial class LogInForm : Form
    {
        String str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Study Material\C#Projects\BankManagementSystem\BankManagementSystem\MyBank_DB.mdf;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;

        public LogInForm()
        {
            InitializeComponent();
            con=new SqlConnection(str);
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            if(txtEmail.Text =="" && txtPass.Text == "")
            {
                MessageBox.Show("please enter Email and Pass");

            }
            else
            {
                try
                {
                    con.Open();
                    cmd = new SqlCommand("select * from tb_SignUp where Email=@Email and Pass=@Pass",con);
                    cmd.Parameters.Add("@Email",txtEmail.Text);
                    cmd.Parameters.Add("@Pass", txtPass.Text);
                    SqlDataAdapter adpt=new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet(); 
                    adpt.Fill(ds);

                    int count=ds.Tables[0].Rows.Count;
                    if (count == 1)
                    {
                        MessageBox.Show("You have successfully LogIn");
                    }
                    else
                    {
                        MessageBox.Show("Please check the Email or Pass");
                    }
                    con.Close();


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
               UserRegisterationFormcs userRegisterationFormcs = new UserRegisterationFormcs();
                userRegisterationFormcs.Show();
                this.Hide();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SignUpForm c=new SignUpForm();
            c.Show();
            this.Hide();
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UserRegisterationFormcs userRegisterationFormcs=new UserRegisterationFormcs();
            userRegisterationFormcs.Show();
            this.Hide();
        }

        private void prevToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SignUpForm signUpForm=new SignUpForm();
            signUpForm.Show();
            this.Hide();
        }
    }
}
